package HomeWork;

public class Cube {
    public static void main(String[] args) {
        int c = 3;
        System.out.println(Math.pow (c, 3));
    }
}
