package HomeWork;

public class Delta {
    public static void main(String[] args) {
        int a = 5;
        int h = 16;
        double S = 0.5 * a * h;
        System.out.println(S);

    }
}
