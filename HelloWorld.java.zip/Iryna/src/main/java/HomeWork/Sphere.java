package HomeWork;

public class Sphere {
    public static void main(String[] args) {
        final var pi = 3.14;
        double R = 16.5;
        double S = 4 * pi * Math.pow(R, 2);
        System.out.println(S);
    }
}
