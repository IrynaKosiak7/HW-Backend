package HomeWork;

public class Trapezium {
    public static void main(String[] args) {
        int a = 5;
        int b = 17;
        int c = 9;
        int d = 20;
        int per = a + b + c + d;

        System.out.println(per);
    }
}
